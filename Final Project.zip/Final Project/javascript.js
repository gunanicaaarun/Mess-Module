//firstnamecheck to check the firstname

function firstnamecheck()
{
    var field=document.getElementById("firstname").value;
    var regex=/^[a-zA-Z ]*$/;

    if(regex.test(field))
        document.getElementById("msg1").innerHTML="Valid";
    
    else
        document.getElementById("msg1").innerHTML="Enter characters!";

}

//lastnamecheck function to check the lastname
function lastnamecheck()
{
    var field=document.getElementById("lastname").value;
    var regex=/^[a-zA-Z ]*$/;

    if(regex.test(field))
        document.getElementById("msg2").innerHTML="Valid";
    
    else
        document.getElementById("msg2").innerHTML="Enter characters!";

}

//to check the country input
function countrycheck()
{
    var field=document.getElementById("country").value;

    if(field.length<3)
        document.getElementById("msg3").innerHTML="Please enter the country name";
    
    else
        document.getElementById("msg3").innerHTML="Valid";

}

//to simple deliver the msg
function buttonclick()
{
    document.getElementById("sentmsg").innerHTML="Message sucessfully sent!";
 
}